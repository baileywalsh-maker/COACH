// "Try v143" buttons for the demo. Edit per version.
(function(){
  const closeAll = () => ['add-backdrop','review-backdrop','weighin-backdrop'].forEach(id => { try{ closeSheet(id); }catch(e){} });
  const search = q => { closeAll();
    document.getElementById('open-add').click();
    setTimeout(()=>{ try{ packetsLoad(); }catch(e){} const si = document.getElementById('search-input'); si.value = ''; let i = 0;
      const t = setInterval(()=>{ si.value = q.slice(0, ++i); si.dispatchEvent(new Event('input')); if(i >= q.length) clearInterval(t); }, 120); }, 400); };
  window.TRYIT = [
    ['Search: typo "weetabx"', ()=>search('weetabx')],
    ['Search: typo "chiken brest"', ()=>search('chiken brest')],
    ['Search: Costa food', ()=>search('costa muffin')],
    ['Weekly review (shorter)', ()=>{ closeAll(); reviewPeriod = 'week'; renderReviewSheet(null); openSheet('review-backdrop'); }],
    ['Data screen', ()=>{ closeAll(); switchView('data'); }],
    ['Suggested change card', ()=>{ closeAll(); switchView('day');
      const real = adaptSuggestion; window.adaptSuggestion = ()=>Object.assign(real(), {state:'suggest', from: 2900, to: 2750, tdee: 2800, se: 90, avgIntake: 2880, weekly: 0.12, rate: -0.25, weighIns: 14, fullDays: 26, capped: false, floored: false});
      currentDate = new Date(); renderAdaptCard(); const c = document.getElementById('adapt-card'); c.classList.add('tf-open'); try{ renderTodayChips(); }catch(e){} window.adaptSuggestion = real; window.scrollTo({top: 0, behavior: 'smooth'}); }]
  ];
})();
