// "Try v142" buttons for the demo. Edit per version.
window.TRYIT = [
  ['Profile: Save bar', ()=>{ document.getElementById('profile-btn').click(); setTimeout(()=>{ const s = document.querySelector('#profile-backdrop .sheet'); s.scrollTo({top: s.scrollHeight, behavior: 'smooth'}); }, 500); }],
  ['Settings: less text', ()=>{ document.getElementById('target-btn').click(); }],
  ['Storage line', ()=>{ document.getElementById('target-btn').click(); setTimeout(()=>{ const s = document.querySelector('#target-backdrop .sheet'); s.scrollTo({top: s.scrollHeight, behavior: 'smooth'}); }, 500); }],
  ['Water page', ()=>{ try{ openSheet('waterpage-backdrop'); }catch(e){} }],
  ['Weigh-in', ()=>{ try{ openSheet('weighin-backdrop'); }catch(e){} }]
];
